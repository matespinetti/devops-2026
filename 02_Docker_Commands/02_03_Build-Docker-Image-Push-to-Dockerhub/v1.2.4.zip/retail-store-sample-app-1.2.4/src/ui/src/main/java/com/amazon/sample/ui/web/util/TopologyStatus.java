package com.amazon.sample.ui.web.util;

public enum TopologyStatus {
  HEALTHY,
  UNHEALTHY,
  NONE,
}
